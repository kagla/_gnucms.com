<%
	'// 날짜 문자열 구하기, oid 생성용
	Function getDateTimeFormat()
		Dim reValue
		
		reValue = Replace("yyyymmddhn", "yyyy", Year(now()))
		reValue = Replace(reValue, "mm", right("0" & Month(now()) , 2))
		reValue = Replace(reValue, "dd", right("0" & Day(now()) , 2))
		reValue = Replace(reValue, "h", right("0" & Hour(now()) , 2))
		reValue = Replace(reValue, "n", right("0" & Minute(now()) , 2))

		getDateTimeFormat = reValue & Right("000" & (Timer * 1000) Mod 1000, 3)
	End Function
	
	'// SHA512 인코딩
	public Function SHA512(sText)
		Set objUnicode = CreateObject("System.Text.UTF8Encoding")
		Set objSHA512 = CreateObject("System.Security.Cryptography.SHA512Managed")
		
		arrByte = objUnicode.GetBytes_4(sText)
		strHash = objSHA512.ComputeHash_2((arrByte))
		SHA512 = ToBase64(strHash)
		
		Set objUnicode = NOTHING
		Set objSHA512 = NOTHING
	End Function
	
	'// Base64 인코딩
	Function ToBase64(rabyt)
		Set xml = CreateObject("MSXML2.DOMDocument.3.0")
		
		xml.LoadXml "<root />"
		xml.documentElement.dataType = "bin.base64"
		xml.documentElement.nodeTypedValue = rabyt
		strBase64 = xml.documentElement.Text
		
		ToBase64 = Replace(Replace(strBase64, Chr(10), ""), Chr(13), "")
		
		Set xml = NOTHING
	End Function
%>
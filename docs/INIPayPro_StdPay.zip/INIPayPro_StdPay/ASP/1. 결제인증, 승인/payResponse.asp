<% @Language="VBScript" CODEPAGE="65001" %>

<%
	Response.charset = "utf-8"
	Response.ContentType="text/html"
	Response.codePage=65001
	Session.codePage=65001
%>

<%
	'/*********************************************************************
	' * 일반결제(신용카드, 계좌이체, 무통장입금) 인증결과
	' *********************************************************************/
	set paramMap = CreateObject("Scripting.Dictionary")
	'//----------------------
	'// 1. 인증 파라미터 일괄 수신
	'//----------------------
	For Each item In Request.Form
		paramMap.add item , Request.Form(item)
	Next

	'/*********************************************************************
	' * 인증 성공 시 결제 승인 요청
	' *********************************************************************/
	applResultData = ""
	
	If paramMap("P_STATUS") = "00" Then
		'//----------------------
		'// 1. 파라미터 설정
		'//----------------------
		P_MID = paramMap("P_MID")
		P_AUTH_TID = paramMap("P_AUTH_TID")
		P_AMT = paramMap("P_AMT")
		P_CHARSET = paramMap("P_CHARSET")
		
		'// 결제 승인 요청 URL
		requestURL = "https://" & paramMap("P_IDCNAME") & "paypro.inicis.com/payment/v1/rest/payAppl.ini"
		
		'//----------------------
		'// 2. API 요청 전문 생성
		'//----------------------
		sendParam = "P_MID=" & P_MID
		sendParam = sendParam & "&P_AUTH_TID=" & P_AUTH_TID
		sendParam = sendParam & "&P_AMT=" & P_AMT
		sendParam = sendParam & "&P_CHARSET=" & P_CHARSET
		
		'//----------------------
		'// 3. API 통신 시작
		'//----------------------
		Set xmlHttp = CreateObject("Msxml2.XMLHTTP")
		
		xmlHttp.Open "POST", requestURL, False
 		xmlHttp.setRequestHeader "Content-Type", "application/x-www-form-urlencoded; text/html; charset=utf-8"
		xmlHttp.Send sendParam
		
		'//----------------------
		'// 4. API 통신 결과 처리
		'//----------------------
		applResultData=Cstr( xmlHttp.responseText )
		
		Set xmlHttp = NOTHING
	End If

	'/*********************************************************************
	' * 인증결과 데이터 출력
	' *********************************************************************/
	authParameterTable = "<table border='1'><tr style='background-color:#bbb;'><td>KEY</td><td>VAULE(length)</td></tr>"
	
	For Each key In paramMap
		authParameterTable = authParameterTable & "<tr><td style='width:100px;'>" & key & "</td><td>" & paramMap(key) & " : " & LEN(paramMap(key)) & "</td></tr>"
	Next
	
	authParameterTable = authParameterTable & "</table>"
	
	
	'/*********************************************************************
	' * 승인결과 데이터 출력 (인증에 실패한 경우 승인요청을 하지 않기 때문에 출력하지 않는다.)
	'*********************************************************************/
	applParamTable = ""
	
	If applResultData <> "" Then
		applParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>"

		For Each data In split(applResultData,"&")
		
			If Ubound(split(data,"=")) = 1 Then
				key = split(data,"=")(0)
				value = split(data,"=")(1)
				applParamTable = applParamTable & "<tr><td style='width:100px;'>" & key & "</td><td>" & value & " : " & LEN(value) & "</td></tr>"
			End If
		Next
		
		applParamTable = applParamTable & "</table>"
	End If
%>
<!DOCTYPE HTML>
<html>
	<head lang="ko">
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;" />
		<meta name="viewport" content="width=device-width;initial-scale=1.0;minimum-scale=1.0;maximum-scale=1.0;user-scalable=no" />
		<style>
			body 
			{
				background : white;
			}
			
			h3
			{
				font-size : 15px;
				margin : 0px;
				margin-left : 10px;
			}
			
			h4
			{
				font-weight : 400;
				font-size : 15px;
				margin : 0px;
				margin-left : 10px;
			}
			
			table
			{
				min-width: 200px;
				max-width: calc(100% - 25px);
				width: 100%;
				margin: 0 auto;
				text-align : right;
				border: 1px solid black;
			}
			
			td
			{
				max-width: 280px;
				word-break: break-all;
				border: 1px solid black;
			}
		</style>
	</head>
	<body>
		<h3>인증 결과</h3><br/>
		<%=authParameterTable%>
		<br/>
		<% If paramMap("P_STATUS") <> "00" Then %>
			<h4>
				인증에 실패하였습니다. </br>
				인증실패 사유 : <%=paramMap("P_RMESG")%>
			</h4>
		<%	
			End If 
		%>
		
		<% If applParamTable <> "" Then %>
			</br>
			<h3>승인 결과</h3></br>
			<%=applParamTable%>
		<%	
			End If 
		%>
	</body>
</html>
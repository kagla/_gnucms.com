<?php
	/*********************************************************************
	 * 일반결제(신용카드, 계좌이체, 무통장입금) 인증결과
	 *********************************************************************/
	//----------------------
	// 1. 인증 파라미터 일괄 수신
	//----------------------
	foreach($_REQUEST as $key => $value){
		$paramMap[$key] = $value;
	}

	/*********************************************************************
	 * 인증 성공 시 결제 승인 요청
	 *********************************************************************/
	 $applResultData = "";
	 
	if($paramMap['P_STATUS'] == "00"){
		//----------------------
		// 1. 파라미터 설정
		//----------------------
		$P_MID = $paramMap['P_MID'];
		$P_AUTH_TID = $paramMap['P_AUTH_TID'];
		$P_AMT = $paramMap['P_AMT'];
		$P_CHARSET = "UTF-8";
		
		// 결제 승인 요청 URL
		$requestURL = "https://".$paramMap['P_IDCNAME']."paypro.inicis.com/payment/v1/rest/payAppl.ini";
		
		//----------------------
		// 2. API 요청 전문 생성
		//----------------------
		$sendParam = "P_MID=".$P_MID;
		$sendParam = $sendParam."&P_AUTH_TID=".$P_AUTH_TID;
		$sendParam = $sendParam."&P_AMT=".$P_AMT;
		$sendParam = $sendParam."&P_CHARSET=".$P_CHARSET;
		
		try{
			//----------------------
			// 3. API 통신 시작
			//----------------------
			$handle = curl_init();
			
			$opt = array(
				CURLOPT_URL => $requestURL,					// 통신 URL
				CURLOPT_POSTFIELDS => $sendParam,			// 통신 전송 데이터
				CURLOPT_CONNECTTIMEOUT => 10,				// Connect Timeout
				CURLOPT_RETURNTRANSFER => true,				// 통신 결과를 문자열로 반환할지 여부		
				CURLOPT_POST => true,						// POST 통신 여부
				CURLOPT_SSL_VERIFYPEER => false,			// 원격 서버의 인증서 유효 검사 실행 여부
				CURLOPT_HTTPHEADER => ["Content-Type: application/x-www-form-urlencoded; charset=UTF-8"],
			);
			
			curl_setopt_array($handle, $opt);
			
			//----------------------
			// 4. API 통신 결과 처리
			//----------------------
			$applResultData = curl_exec($handle);
			
		} finally{
			curl_close($handle);
		}
	}
	
	/*********************************************************************
	 * 인증결과 데이터 출력
	 *********************************************************************/
	$authParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";
	 
	foreach($paramMap as $key => $value){
		$authParamTable = $authParamTable."<tr><td style='width: 100px;'>".$key."</td><td>".$value." : ".strlen($value)."</td></tr>";
	}
	
	$authParamTable = $authParamTable."</table>";

	
	/*********************************************************************
	 * 승인결과 데이터 출력 (인증에 실패한 경우 승인요청을 하지 않기 때문에 출력하지 않는다.)
	 *********************************************************************/
	$applParamTable = "";
	 
	if($applResultData != ""){
		$applParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";
			
		foreach(explode("&", $applResultData) as $data){
			if(count(explode("=", $data)) < 2){
				continue;
			};
			$key = explode("=", $data)[0];
			$value = explode("=", $data)[1];
					
			$applParamTable = $applParamTable."<tr><td style='width: 100px;'>".$key."</td><td>".$value." : ".strlen($value)."</td></tr>";
		}
				
		$applParamTable = $applParamTable."</table>";
	}
	
?>
<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<html lang="ko">
<head>
<style>

body {
	background: white;
}

h3{
	font-size:15px;
	margin: 0px;
	margin-left: 10px;
}
h4{
	font-weight:400;
	font-size:15px;
	margin: 0px;
	margin-left: 10px;
}

table {
	min-width: 200px;
	max-width: calc(100% - 25px);
	width: 100%;
	margin: 0 auto;
	text-align: right;
	border: 1px solid black;
}

td {
	max-width: 280px;
	word-break: break-all;
	border: 1px solid black;
}

</style>
</head>
<body>
	
	<h3>인증 결과</h3></br>
	<?php echo $authParamTable; ?>
	</br>
	<?php 
		if($paramMap['P_STATUS'] != "00"){
			echo "<h4>";
			echo "인증에 실패하였습니다. </br>";
			echo "인증실패 사유 : ".$paramMap['P_RMESG'];
			echo "</h4>";
		}
	?>
	
	<?php 
		if($applResultData != ""){
			echo "</br>";
			echo "<h3>승인 결과</h3></br>";
			echo $applParamTable;
		}
	?>
</body>


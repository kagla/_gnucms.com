<?php
	$dateTime = date("YmdHis");
	$timeStamp = time();
	
	$mid = "INIpayTest";
	$amt = "1000";
	$oid = $mid.$dateTime;
	$hashkey = "3CB8183A4BE283555ACC8363C0360223";
	$timestamp = $timeStamp;
	$beforeEnc = $amt.$oid.$timestamp.$hashkey;
	
	$afterEnc = base64_encode(hash("sha512", $beforeEnc, true));
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 	<script src="https://paypro.inicis.com/std/payment/js/INIPayPro_v2.js" charset="UTF-8"></script>
	<script>
	//var url = "https://[가맹점도메인]";														// 가맹점 DOMAIN
	var url = "https://paypro.inicis.com";			// 가맹점 DOMAIN 예시										
	
	function request() {
		var obj = {
				P_MID			: "<?=$mid?>"										,		// 가맹점 아이디									EX) EDGETestId
				P_OID			: "<?=$oid?>"										,		// 가맹점 주문번호(Unique 값)						EX) EDGETestId202306081631579 
				P_PAY_TYPE		: "CARD"											,		// 결제수단										EX) CARD, VBANK, BANK, ...
				P_DEVICE_TYPE	: "WEB"												,		// 디바이스타입									EX) WEB, MOBILE
				P_IDCCODE		: "Y"												,		// IDC 센터 코드 사용								EX) Y 고정
				P_AMT			: "<?=$amt?>"										,		// 결제금액
				P_GOODS			: "이니시스 테스트 상품"									,		// 상품명
				P_UNAME			: "홍길동" 											,		// 구매자명
				P_NEXT_URL		: url + "/payResponse.php"							,		// 인증 결과 수신 URL
				P_NOTI_URL		: url + "/sample/payment/rest/recvNoti"				,		// 가상계좌 입금통보 URL
				P_CLOSE_URL		: "https://www.google.com"							,		// 결제창 닫기 요청 URL
				P_CHARSET		: "UTF-8"											,		// 결과 인코딩 옵션
				P_NOTI			: "가맹점예약필드"										,		// 가맹점 임의 데이터 
				P_TIMESTAMP     : "<?=$timeStamp?>"									,		// 타임스탬프
				P_CHKFAKE		: "<?=$afterEnc?>"									,		// 위변조 검증 데이터															
				P_RESERVED		: '{"email":"test@kggroup.co.kr"}'							// 선택 옵션, 빈값 또는 JSON String 형식으로 입력
			};
		
		/* SDK 함수호출  */
		INIPayPro.requestPayment(obj);
	}
	</script>
</head>
<body>
	<div>
		<input type="button" onclick="request()" value="인증요청"/>
	</div>
</body>
</html>
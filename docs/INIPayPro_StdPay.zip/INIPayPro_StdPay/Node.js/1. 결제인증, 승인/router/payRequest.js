const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const fileName = 'payRequest';

  const crypto = require("crypto");

  const dateTime = getDateTime();
  const timeStamp = Date.now();

  const mid = "INIpayTest";
  const oid = mid + dateTime;
  const amt = "1000";
  const hashkey = "3CB8183A4BE283555ACC8363C0360223";
  const timestamp = timeStamp;
  const beforeEnc = amt + oid + timestamp + hashkey;
  const afterEnc = crypto.createHash("sha512").update(beforeEnc).digest("base64");
  
  res.render(fileName, {
    mid : mid,
    oid : oid,
    amt : amt,
    timestamp : timestamp,
    afterEnc : afterEnc
  });
});

function getDateTime(){
  const date = new Date();

  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const milliseconds = String(date.getMilliseconds()).padStart(3, '0');

  return `${year}${month}${day}${hours}${minutes}${milliseconds}`;
}
module.exports = router;

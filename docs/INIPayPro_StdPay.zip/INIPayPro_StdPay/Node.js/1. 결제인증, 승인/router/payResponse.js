const express = require('express');
const router = express.Router();
const https = require('https');

router.post('/', (req, res) => {
  /***********************************************************************************
   * 일반결제(신용카드, 계좌이체, 무통장입금) 인증결과
   ***********************************************************************************/
  //---------------------------
  // 1. 인증 파라미터 일괄 수신
  //---------------------------
  let paramMap = new Map();

  for (const key in req.body) {
    paramMap.set(key, req.body[key]);
  }
  /***********************************************************************************
   * 인증 성공 시 결제 승인 요청
   ***********************************************************************************/
  if(paramMap.get('P_STATUS') === "00"){
    //---------------------------
    // 1. 파라미터 설정
    //---------------------------
    let P_MID = paramMap.get('P_MID');
    let P_AUTH_TID = paramMap.get('P_AUTH_TID');
    let P_AMT = paramMap.get('P_AMT');
    let P_CHARSET = "UTF-8";
    
    // 결제 요청 URL
    let requestUrl = `https://${paramMap.get('P_IDCNAME')}paypro.inicis.com/payment/v1/rest/payAppl.ini`;

    //---------------------------
    // 2. API 요청 전문 생성
    //---------------------------
    let sendParam = `P_MID=${P_MID}`;
    sendParam += `&P_AUTH_TID=${P_AUTH_TID}`;
    sendParam += `&P_AMT=${P_AMT}`;
    sendParam += `&P_CHARSET=${P_CHARSET}`;
    
    //---------------------------
    // 3. API 통신 시작
    //---------------------------
    const httpOptions = {
      method : 'POST',
      headers : {
        'Content-Type' : 'application/x-www-form-urlencoded; charset=utf-8'
      }
    };
    
    const request = https.request(requestUrl, httpOptions, (response) => {
      //---------------------------
      // 4. API 통신 결과 처리
      //---------------------------
      let applResultData = "";

      response.setEncoding(P_CHARSET);
      response.on('data', (chunk) => {
        applResultData += chunk;
      });
      
      response.on('end', () => {
        let authParamTable = setAuthParamTable(paramMap);
        let applParamTable = setApplParamTable(applResultData);
        responseRender(res, paramMap, authParamTable, applParamTable);
      });
    });
    
    request.write(sendParam);
    request.end();
  } else {
    let authParamTable = setAuthParamTable(paramMap);
    responseRender(res, paramMap, authParamTable, "");
  }
  
});

/***********************************************************************************
 * 인증결과 데이터 출력
***********************************************************************************/
function setAuthParamTable(paramMap) {
  let authParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";
  for(let key of paramMap.keys()){
    authParamTable += `<tr><td style='width: 100px;'>${key}</td><td>${paramMap.get(key)} : ${Buffer.byteLength(paramMap.get(key))}</td></tr>`;
  }
  authParamTable += "</table>";

  return authParamTable;

}

/***********************************************************************************
 * 승인결과 데이터 출력 (인증에 실패한 경우 승인요청을 하지 않기 때문에 출력하지 않는다.)
***********************************************************************************/  
function setApplParamTable(applResultData){
  let applParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";
    
    for(let data of applResultData.split("&")){
      if(data.split("=").length < 2){
        continue;
      }
       
      let key = data.split("=")[0];
      let value = data.split("=")[1];
      
      applParamTable += `<tr><td style='width: 100px;'>${key}</td><td>${value} : ${Buffer.byteLength(value)}</td></tr>`;

    }
    applParamTable += "</table>";
  return applParamTable;

}

function responseRender(res, paramMap, authParamTable, applParamTable){
  const fileName = 'payResponse';
  // res.setHeader('Content-Type', 'text/html');
  res.render(fileName, {
    paramMap : paramMap,
    authParamTable : authParamTable,
    applParamTable : applParamTable
  });
}

module.exports = router;

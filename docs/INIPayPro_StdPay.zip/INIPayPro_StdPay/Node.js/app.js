const express = require('express');

const app = express();
const PORT = 8080;

app.set('view engine', 'ejs');

app.use(express.urlencoded({
  extended : false
}));

const payRequest = require("./router/payRequest");
const payResponse = require("./router/payResponse");

app.use("/payRequest", payRequest);
app.use("/payResponse", payResponse);

app.listen(PORT, 'localhost', () => {
  console.log(`Server is listening at localhost on port ${PORT}`);
});
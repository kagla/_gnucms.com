<%@page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@page import="java.io.*"%>
<%@page import="java.net.URL"%>
<%@page import="java.net.URLConnection"%>
<%@page import="java.util.*"%>
<%
	/*********************************************************************
	 * 일반결제(신용카드, 계좌이체, 무통장입금) 인증결과
	 *********************************************************************/
	Enumeration params = request.getParameterNames();
	Map<String, String> paramMap = new HashMap<String,String>();
	//----------------------
	// 1. 인증 파라미터 일괄 수신
	//----------------------
	while(params.hasMoreElements()){
		String paramName = (String) params.nextElement();
		String paramValue = new String(request.getParameter(paramName).getBytes("8859_1"), "UTF-8");
		
		paramMap.put(paramName, paramValue);
	}
	
	/*********************************************************************
	 * 인증 성공 시 결제 승인 요청
	 *********************************************************************/
	 String applResultData = "";
	 
	if("00".equals(paramMap.get("P_STATUS"))){
		//----------------------
		// 1. 파라미터 설정
		//----------------------
		String P_MID = paramMap.get("P_MID");
		String P_AUTH_TID = paramMap.get("P_AUTH_TID");
		String P_AMT = paramMap.get("P_AMT");
		String P_CHARSET = "UTF-8";
		
		// 결제 승인 요청 URL
		String requestURL = "https://" + paramMap.get("P_IDCNAME") + "paypro.inicis.com/payment/v1/rest/payAppl.ini";
		
		//----------------------
		// 2. API 요청 전문 생성
		//----------------------
		String sendParam = "P_MID=" + P_MID;
		sendParam += "&P_AUTH_TID=" + P_AUTH_TID;
		sendParam += "&P_AMT=" + P_AMT;
		sendParam += "&P_CHARSET=" + P_CHARSET;
	
		try {
			//----------------------
			// 3. API 통신 시작
			//----------------------
			URL sendUrl = new URL(requestURL);
			URLConnection uc = sendUrl.openConnection();
			uc.setDoOutput(true);	// POST
			
			OutputStream raw = uc.getOutputStream();
			OutputStream buffered = new BufferedOutputStream(raw);
			OutputStreamWriter osw = new OutputStreamWriter(buffered);
			osw.write(sendParam);
			osw.flush();
			osw.close();
			
			//----------------------
			// 4. API 통신 결과 처리
			//----------------------
			InputStreamReader isr = new InputStreamReader(uc.getInputStream(), P_CHARSET);
			
			BufferedReader br = new BufferedReader(isr);
			StringBuffer sb = new StringBuffer();
			String nextLine = null;
			
			while((nextLine = br.readLine()) != null){
				sb.append(nextLine);
			}
			
			applResultData = sb.toString();

		} catch (IOException ex) {
			out.print(ex);
		}
	}
	
	/*********************************************************************
	 * 인증결과 데이터 출력
	 *********************************************************************/
	 String authParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";

	 for(String key : paramMap.keySet()){
		 authParamTable += "<tr><td style='width: 100px;'>"+ key +"</td><td>" + paramMap.get(key) + " : " + paramMap.get(key).getBytes().length + "</td></tr>";
	 } 
	 
	 authParamTable += "</table>";
	 
	/*********************************************************************
	 * 승인결과 데이터 출력 (인증에 실패한 경우 승인요청을 하지 않기 때문에 출력하지 않는다.)
	*********************************************************************/
	String applParamTable = "";
	
	if(applResultData != ""){
		applParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";

		for(String data  : applResultData.split("&")){
			if(data.split("=").length < 2){
				continue;
			};
			String key = data.split("=")[0];
			String value = data.split("=")[1];
			
			applParamTable += "<tr><td style='width: 100px;'>"+ key +"</td><td>" + value + " : " + value.getBytes().length + "</td></tr>";
		} 
		applParamTable += "</table>";
	}
	
%>

<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<html lang="ko">
<head>
<style>

body {
	background: white;
}

h3{
	font-size:15px;
	margin: 0px;
	margin-left: 10px;
}
h4{
	font-weight:400;
	font-size:15px;
	margin: 0px;
	margin-left: 10px;
}

table {
	min-width: 200px;
	max-width: calc(100% - 25px);
	width: 100%;
	margin: 0 auto;
	text-align: right;
	border: 1px solid black;
}

td {
	max-width: 280px;
	word-break: break-all;
	border: 1px solid black;
}

</style>
</head>
<body>
	
	<h3>인증 결과</h3></br>
	<%
		out.println(authParamTable);
		out.flush();
	%>
	</br>
	<% if(!paramMap.get("P_STATUS").equals("00")) { %>
		<h4>
			인증에 실패하였습니다. </br>
			인증실패 사유 : <%=paramMap.get("P_RMESG")%>
		</h4>
	<% 
		} 
	%>

	<% if(applResultData != "") { %>
		</br>
		<h3>승인 결과</h3></br>
		<%
			out.println(applParamTable);
			out.flush();
		%>
	<%
		}
	%>

</body>


﻿<%@ Page Language="C#" AutoEventWireup="true" %>
<%
	/*********************************************************************
	 * 일반결제(신용카드, 계좌이체, 무통장입금) 인증요청
	 *********************************************************************/
	var dateTime = DateTime.Now.ToString("yyyyMMddHHmmss");
	DateTime jan1st1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
	var timeStamp = (long)(DateTime.UtcNow - jan1st1970).TotalMilliseconds;

	var mid = "INIpayTest";
	var amt = "1000";
	var oid = mid + dateTime;
	var hashkey = "3CB8183A4BE283555ACC8363C0360223";

	var beforeEnc = amt + oid + timeStamp + hashkey;
	byte[] data = Encoding.UTF8.GetBytes(beforeEnc);
	var sha = new System.Security.Cryptography.SHA512Managed();
	byte[] result = sha.ComputeHash(data);
	var afterEnc = Convert.ToBase64String(result);
%>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title></title>
</head>

<script src="https://paypro.inicis.com/std/payment/js/INIPayPro_v2.js" charset="UTF-8"></script>
<script>

	//var url = "https://[가맹점도메인]";											// 가맹점 DOMAIN
	var url = "https://paypro.inicis.com";										// 가맹점 DOMAIN 예시

    function request() {
        var obj = {
            P_MID			:	'<%=mid%>'								,		// 가맹점 아이디								EX) EDGETestId
            P_OID			:	'<%=oid%>'								,		// 가맹점 주문번호(Unique 값)					EX) EDGETestId202306081631579
            P_PAY_TYPE		:	"VBANK"									,		// 결제수단									EX) CARD, VBANK, BANK, ...
            P_DEVICE_TYPE	:	"WEB"									,		// 디바이스타입								EX) WEB, MOBILE
            P_IDCCODE		:	"Y"										,		// IDC 센터 코드 사용							EX) Y 고정
            P_AMT			:	'<%=amt%>'								,		// 결제금액
            P_GOODS			:	"이니시스 테스트 상품"						,		// 상품명
            P_UNAME			:	"홍길동" 									,		// 구매자명
            P_NEXT_URL		:	url + "/PayResponse.aspx"				,		// 인증 결과 수신 URL
            P_NOTI_URL		:	url + "/sample/payment/rest/recvNoti"	,		// 가상계좌 입금통보 URL
            P_CLOSE_URL		:	""										,		// 결제창 닫기 요청 URL
            P_CHARSET		:	"UTF-8"									,		// 결과 인코딩 옵션
            P_NOTI			:	"ASP 가맹점 예약 필드"						,		// 가맹점 임의 데이터
            P_TIMESTAMP		:	'<%=timeStamp%>'						,		// 타임스탬프
            P_CHKFAKE		:	'<%=afterEnc%>'							,		// 위변조 검증 데이터
            P_RESERVED		:	'{"email":"test@kggroup.co.kr"}'				// 선택 옵션, 빈값 또는 JSON String 형식으로 입력
        }
        INIPayPro.requestPayment(obj);
    }

</script>
<body>
    <div>
        <input type="button" onclick="request()" value="인증요청"/>

    </div>
</body>
</html>

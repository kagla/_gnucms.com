﻿<%@ Page Language="C#" AutoEventWireup="true" %>
<%
 /*********************************************************************
 * 일반결제(신용카드, 계좌이체, 무통장입금) 인증결과
 *********************************************************************/
	Hashtable paramMap = new Hashtable();

	//----------------------
	// 1. 인증 파라미터 일괄 수신
	//----------------------
	foreach(string key in Request.Form)
	{
		string value = Request.Form[key].ToString();
		paramMap.Add(key, value);
	}
	
	Encoding charset = Encoding.UTF8;
	if (paramMap["P_CHARSET"].Equals("EUC-KR"))
	{
		charset = Encoding.GetEncoding(51949);
	}
	
	var p_idcname = paramMap["P_IDCNAME"];
	var requestUrl = "https://" + p_idcname + "paypro.inicis.com/payment/v1/rest/payAppl.ini";
	string authParamTable = "";
	string applParamTable = "";
	string applResultData = "";
	
	/*********************************************************************
	 * 인증 성공 시 결제 승인 요청
	 *********************************************************************/
	if ("00".Equals(paramMap["P_STATUS"])){
		try
		{
			var request = System.Net.WebRequest.Create(requestUrl);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded";

			//----------------------
			// 1. API 요청 전문 생성
			//----------------------
			string postData = "P_MID=" + paramMap["P_MID"].ToString();
			postData += "&P_AUTH_TID=" + paramMap["P_AUTH_TID"].ToString();
			postData += "&P_AMT=" + paramMap["P_AMT"].ToString();
			postData += "&P_CHARSET=" + paramMap["P_CHARSET"].ToString();

			var data = Encoding.ASCII.GetBytes(postData);

			request.ContentLength = data.Length;
			
			//----------------------
			// 3. API 통신 시작
			//----------------------
			using(var stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}
			var applResponseData = (System.Net.HttpWebResponse)request.GetResponse();

			//----------------------
			// 4. API 통신 결과 처리
			//----------------------
			using(System.IO.Stream stream = applResponseData.GetResponseStream())
			{
				System.IO.StreamReader reader = new System.IO.StreamReader(stream, charset);
				applResultData = reader.ReadToEnd();
			}
		}
		catch (System.Net.WebException ex)
		{
			Console.WriteLine(ex.Message);
		}
		
		/*********************************************************************
		 * 인증결과 데이터 출력
		 *********************************************************************/
		authParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";

		foreach(var item in paramMap.Keys)
		{
			authParamTable += "<tr><td style='width:100px;'>" + item + "</td><td>" + paramMap[item] + ":" + charset.GetBytes(paramMap[item].ToString()).Length + "</td></tr>";
		}
		authParamTable += "</table>";


		/*********************************************************************
		 * 승인결과 데이터 출력 (인증에 실패한 경우 승인요청을 하지 않기 때문에 출력하지 않는다.)
		*********************************************************************/
		if(applResultData != "")
		{
			applParamTable = "<table border='1'><tr style='background-color:#bbb'><td>KEY</td><td>VALUE(length)</td></tr>";

			foreach(var item in applResultData.Split('&')){
				if(item.Split('=').Length < 2)
				{
					continue;
				}

				string key = item.Split('=')[0];
				string value = item.Split('=')[1];

				applParamTable +="<tr><td style='width:100px;'>" + key + "</td><td>" + value + ":" + charset.GetBytes(value.ToString()).Length + "</td></tr>";
			}
			applParamTable += "</table>";
		}
	}

%>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>인증결과</title>
<style>
	body{
		background: white;
	}

	h3{
		font-size: 15px;
		margin: 0px;
		margin-left: 10px;
	}

	h4{
		font-weight:400;
		font-size: 15px;
		margin: 0px;
		margin-left: 10px;
	}

	table{
		min-width: 200px;
		max-width: calc(100% - 25px);
		width: 100%;
		margin: 0 auto;
		text-align: right;
		border: 1px solid black;

	}

	td{
		max-width: 280px;
		word-break: break-all;
		border: 1px solid black;
	}
</style>
</head>
<body>
    <h3>인증 결과</h3><br/>
    <%= authParamTable %>

    <%if (!paramMap["P_STATUS"].Equals("00"))
      {
    %>
       <h4>
        인증에 실패했습니다<br />
        인증실패 사유 : <%=paramMap["P_RMESG"] %>
       </h4>
    <%
     } 
    %>
    
    <%if (applResultData != "")
      {
    %>
       <br/>
       <h3>승인 결과</h3>
        <br/>
        <%= applParamTable %>
    <%
     } 
    %>
</body>
</html>
